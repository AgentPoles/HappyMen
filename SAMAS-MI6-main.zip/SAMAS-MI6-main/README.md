# SAMAS-MI6
to execute run
.\gradlew.bat or ./gradlew.bat
in the main folder and inside mi6 folder
