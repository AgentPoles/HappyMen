package jason.eis;

import eis.EnvironmentInterfaceStandard;
import eis.iilang.*;
import jason.asSyntax.*;
import jason.eis.Point;
import jason.eis.movements.AgentCollisionHandler;
import jason.eis.movements.Exploration;
import jason.eis.movements.PlannedMovement;
import jason.eis.movements.RandomMovement;
import jason.eis.movements.Search;
import jason.environment.Environment;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;

public class MI6Model {
  private static MI6Model instance;
  public static boolean DEBUG = true; // Make DEBUG public static

  private final Logger logger = Logger.getLogger(
    "MI6Model." + MI6Model.class.getName()
  );
  private final EnvironmentInterfaceStandard ei;
  private final Random random = new Random();
  private static final String[] DIRECTIONS = { "n", "s", "e", "w" };
  private static final int STUCK_THRESHOLD = 3;
  private static final int CLOSE_TARGET_DISTANCE = 5;

  private static final Map<String, String> OPPOSITE_DIRECTIONS = new HashMap<>(
    4
  ) {

    {
      put("n", "s");
      put("s", "n");
      put("e", "w");
      put("w", "e");
    }
  };

  // Movement tracking with efficient data structures
  private final Map<String, MovementHistory> agentMovement;

  // Add failure type constants
  private static final String FAILED_PATH = "failed_path";
  private static final String FAILED_FORBIDDEN = "failed_forbidden";
  private static final String FAILED_PARAMETER = "failed_parameter";
  private static final int MAX_FAILURES_PER_DIRECTION = 3;

  // Optimized zone constants
  private static final int ZONE_SIZE = 10;
  private static final int STEPS_BEFORE_ZONE_CHANGE = 15;
  private static final double ZONE_CHANGE_PROBABILITY = 0.3; // 30% chance to change zone when threshold met
  private static final int MAX_ZONE_DISTANCE = 50; // Prevent zones from getting too far from center

  private static final int BOUNDARY_ESCAPE_ATTEMPTS = 5;
  private static final double RANDOM_ESCAPE_PROBABILITY = 0.4; // 40% chance for random direction when stuck

  // Movement failure tracking constants
  private static final int MAX_CONSECUTIVE_FAILURES = 3;
  private static final long FAILURE_COOLDOWN = 5000; // 5 seconds cooldown for failed directions

  private static class MovementHistory {
    Point lastPosition;
    int stuckCount;
    String lastFailure;
    int failureCount;
    Map<String, Integer> directionFailures;
    Set<String> boundaryDirections; // Track known boundary directions
    int boundaryEscapeAttempts;
    long lastUpdateTime;

    MovementHistory() {
      lastPosition = new Point(0, 0);
      stuckCount = 0;
      lastFailure = null;
      failureCount = 0;
      directionFailures = new HashMap<>();
      boundaryDirections = new HashSet<>();
      boundaryEscapeAttempts = 0;
      lastUpdateTime = System.currentTimeMillis();
    }

    void recordFailure(String direction, String failureType) {
      lastFailure = failureType;
      failureCount++;
      directionFailures.merge(direction, 1, Integer::sum);
    }

    void recordSuccess() {
      lastFailure = null;
      failureCount = 0;
      directionFailures.clear();
    }

    boolean isDirectionReliable(String direction) {
      return (
        directionFailures.getOrDefault(direction, 0) <
        MAX_FAILURES_PER_DIRECTION
      );
    }

    void recordBoundary(String direction) {
      boundaryDirections.add(direction);
      boundaryEscapeAttempts++;
    }

    void clearBoundaryAttempts() {
      boundaryEscapeAttempts = 0;
    }
  }

  // Track zones per agent
  private final Map<String, Zone> agentZones;

  // In MI6Model.java, add:
  private final Map<String, LocalMap> agentMaps;
  private final Map<String, Long> lastProcessedTime;
  private static final long PERCEPT_THRESHOLD = 100; // 100ms threshold

  // Add PerceptCache class definition
  private static class PerceptCache {
    final Point position;
    final BitSet obstacles;
    final long timestamp;

    PerceptCache(Point position, BitSet obstacles) {
      this.position = position;
      this.obstacles = obstacles;
      this.timestamp = System.nanoTime();
    }

    boolean isValid() {
      return System.nanoTime() - timestamp < 100_000_000; // 100ms cache
    }
  }

  private final Map<String, PerceptCache> perceptCache;

  // Store paths for each agent
  private final Map<String, List<String>> agentPaths;
  // Track if an agent is moving towards a dispenser
  private final Map<String, Boolean> movingToDispenser;

  // Add new field declarations
  private final RandomMovement randomMovement;
  private final PlannedMovement plannedMovement;

  // Add a lock object for synchronizing percept and movement processing
  private final Object actionLock = new Object();

  // Track movement failures per agent
  private final Map<String, Map<String, DirectionStatus>> agentDirectionStatus = new ConcurrentHashMap<>();

  // Add these inner classes at the top of MI6Model class, after the constants
  private static class MovementFailure {
    final String direction;
    final String reason;
    final long timestamp;
    final Point position;

    MovementFailure(String direction, String reason, Point position) {
      this.direction = direction;
      this.reason = reason;
      this.timestamp = System.currentTimeMillis();
      this.position = position;
    }
  }

  private static class DirectionStatus {
    int consecutiveFailures = 0;
    long lastFailureTime = 0;
    List<MovementFailure> recentFailures = new ArrayList<>();

    void recordFailure(String agName, String direction, Point position) {
      consecutiveFailures++;
      lastFailureTime = System.currentTimeMillis();
      recentFailures.add(new MovementFailure(direction, "", position));

      // Keep only recent failures
      while (recentFailures.size() > MAX_CONSECUTIVE_FAILURES) {
        recentFailures.remove(0);
      }
    }

    void recordSuccess() {
      consecutiveFailures = 0;
      recentFailures.clear();
    }
  }

  public enum MoveFailureType {
    FORBIDDEN, // Out of grid bounds
    FAILED_PATH, // Blocked by obstacle or other things
    INVALID_PARAM, // Invalid direction
    UNKNOWN, // Other failures
  }

  public MI6Model(EnvironmentInterfaceStandard ei) {
    this.ei = ei;

    // Initialize movement components in correct order
    AgentCollisionHandler collisionHandler = new AgentCollisionHandler();
    Exploration exploration = new Exploration();

    // Initialize movement strategies with updated dependencies
    this.randomMovement = new RandomMovement(collisionHandler, exploration);
    this.plannedMovement = new PlannedMovement();

    // Initialize maps and caches
    this.agentMaps = new ConcurrentHashMap<>();
    this.agentMovement = new ConcurrentHashMap<>();
    this.agentZones = new ConcurrentHashMap<>();
    this.perceptCache = new ConcurrentHashMap<>();
    this.agentPaths = new ConcurrentHashMap<>();
    this.movingToDispenser = new ConcurrentHashMap<>();
    this.lastProcessedTime = new ConcurrentHashMap<>();

    LocalMap.DEBUG = false;
    instance = this;
  }

  public static synchronized MI6Model getInstance() {
    if (instance == null) {
      throw new IllegalStateException("MI6Model not initialized");
    }
    return instance;
  }

  public LocalMap getAgentMap(String agName) {
    LocalMap map = agentMaps.get(agName);
    if (map == null) {
      throw new IllegalStateException("Agent " + agName + " not initialized");
    }
    return map;
  }

  public void initializeAgent(String agName) {
    if (!agentMaps.containsKey(agName)) {
      agentMaps.put(agName, new LocalMap());
      agentMovement.put(agName, new MovementHistory());
      if (LocalMap.DEBUG) {
        logger.info(String.format("[%s] Initialized new agent", agName));
      }
    }
  }

  public void logMapState(String agName) {
    if (LocalMap.DEBUG) {
      try {
        LocalMap map = getAgentMap(agName);
        logger.info(
          "\n=== Map State for Agent " +
          agName +
          " ===\n" +
          map.toString() +
          "\n================================"
        );
      } catch (Exception e) {
        logger.warning(
          "Failed to log map state for agent " + agName + ": " + e.getMessage()
        );
      }
    }
  }

  public RandomMovement getRandomMovement() {
    return randomMovement;
  }

  // Add this method to get agent position
  private Point getAgPos(String agName) {
    LocalMap map = getAgentMap(agName);
    return map.getCurrentPosition();
  }

  public PlannedMovement getPlannedMovement() {
    return plannedMovement;
  }
}
